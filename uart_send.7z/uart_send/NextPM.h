#include <msp430.h>
#include <stdio.h>
#include <string.h>


