#include <msp430.h>
#include <NextPM.h>
#include <stdio.h>
#include "string.h"


