void send_string(unsigned char *ptr);

void send_char(char sendchar);

void to_hex(char *s, int l, char *d);

void from_hex(char *s, int l, char *d);

unsigned char to_dec(char x);

void Init_uart(void);

